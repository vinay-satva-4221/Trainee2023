// var popoverTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="popover"]'))
// var popoverList = popoverTriggerList.map(function (popoverTriggerEl) {
//   return new bootstrap.Popover(popoverTriggerEl)
// })
// var popover = new bootstrap.Popover(document.querySelector('.example-popover'), {
//     container: 'body'
//   })
$(document).ready(function () {
    
    $("#AddNavbar").load("./navbar.html");  
    var loggedData = localStorage.getItem('LoggedInUser');
    if (loggedData) {
        //window.location.replace("dashboard.html");
    }
    else{
        window.location.replace("./login.html");
    }
    // var table = $('#example').DataTable({
    //     "dom": 'rtip',
    //     "ordering": false,

    //     language: {
    //         oPaginate: {
    //             sNext: '<i class="bi bi-caret-right-fill"></i>',
    //             sPrevious: '<i class="bi bi-caret-left-fill"></i>',

    //         }
    //     }

    // });
    // $('#example').removeClass('display').addClass('table table-striped table-bordered');
    // $('#saveStock')
})
