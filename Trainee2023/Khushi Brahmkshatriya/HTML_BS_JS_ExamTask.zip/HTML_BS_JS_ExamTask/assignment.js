$(document).ready(function () {
    $("#AddNavbar").load("./navbar.html");
  
    var loggedData = localStorage.getItem('LoggedInUser');
    if (loggedData) {
      //window.location.replace("dashboard.html");
    }
    else {
      window.location.replace("./login.html");
    }
    
});  